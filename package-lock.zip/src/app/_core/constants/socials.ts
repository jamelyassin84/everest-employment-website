export const SOCIALS = [
    {
        name: 'Facebook',
        image: '/assets/facebook.svg',
    },

    {
        name: 'Instagram',
        image: '/assets/instagram.svg',
    },

    {
        name: 'X former Twitter',
        image: '/assets/twitter.svg',
    },

    {
        name: 'Linked In',
        image: '/assets/linked-in.svg',
    },
]
