export const NAVBAR_NAVIGATION = [
    {
        id: 1,
        name: 'home',
        link: '/home',
    },

    {
        id: 2,
        name: 'about',
        link: '/about',
    },

    {
        id: 3,
        name: 'Our Clients',
        link: '/our-clients',
    },

    {
        id: 4,
        name: 'our Services',
        link: '/our-services',
    },
]
